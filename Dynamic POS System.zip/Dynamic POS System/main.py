import tkinter as tk
import sqlite3
from tkinter import messagebox
from tkinter import font

def initialize_database():
    db_connect = sqlite3.connect('database.db')
    cur_sor = db_connect.cursor()

    # Create the products table
    cur_sor.execute("""
    CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE,
        price REAL
    )
    """)

    # Create the sales table
    cur_sor.execute("""
    CREATE TABLE IF NOT EXISTS sales (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        total_earning REAL
    )
    """)

    db_connect.commit()
    db_connect.close()

initialize_database()

db_connect = sqlite3.connect('database.db')

cur_sor = db_connect.cursor()

cur_sor.execute("""CREATE TABLE IF NOT EXISTS employees (
                username TEXT UNIQUE,
                password TEXT,
                role TEXT
                ) """)

db_connect.commit()

cur_sor.execute("INSERT OR IGNORE INTO employees (username, password, role) VALUES ('admin', '123', 'admin')")
db_connect.commit()
db_connect.close()

#-------------------------------------------------------------------------------------------------------------------------

def authenticate_login(username,password,role):
    db_connect = sqlite3.connect('database.db')
    cur_sor = db_connect.cursor()
    cur_sor.execute("SELECT * FROM employees WHERE username = ? AND password = ? AND role = ?", (username,password,role))
    user = cur_sor.fetchone()
    db_connect.close()
    return user

#-------------------------------------------------------------------------------------------------------------------------

def read_employees():
    db_connect = sqlite3.connect('database.db')
    cur_sor = db_connect.cursor()
    try:
        cur_sor.execute("SELECT rowid, username, role FROM employees")
        employees = cur_sor.fetchall()
        return employees
    except sqlite3.Error as e:
        messagebox.showerror("Error", f"Failed to retrieve employees: {e}")
        return []
    finally:
        db_connect.close()

#-------------------------------------------------------------------------------------------------------------------------

def update_employee(username, new_password, new_role):
    db_connect = sqlite3.connect('database.db')
    cur_sor = db_connect.cursor()
    try:
        # Normalize new_role to lowercase to handle case-insensitive roles
        normalized_role = new_role.lower()

        # Update query with case-insensitive comparison using LOWER
        cur_sor.execute(
            """
            UPDATE employees
            SET password = ?, role = ?
            WHERE username = ?
            """,
            (new_password, normalized_role, username)
        )

        db_connect.commit()

        if cur_sor.rowcount:
            messagebox.showinfo("Success", f"Employee '{username}' updated successfully!")
        else:
            messagebox.showerror("Error", f"Employee '{username}' not found.")

    except sqlite3.Error as e:
        messagebox.showerror("Error", f"Failed to update employee: {e}")

    finally:
        db_connect.close()



def validate_role(role):
    normalized_role = role.lower()
    valid_roles = ["admin", "employee"]
    return normalized_role in valid_roles



def delete_employee(username):
    db_connect = sqlite3.connect('database.db')
    cur_sor = db_connect.cursor()
    try:
        cur_sor.execute("DELETE FROM employees WHERE username = ?", (username,))
        db_connect.commit()
        if cur_sor.rowcount:
            messagebox.showinfo("Success", f"Employee '{username}' deleted successfully!")
        else:
            messagebox.showerror("Error", f"Employee '{username}' not found.")
    except sqlite3.Error as e:
        messagebox.showerror("Error", f"Failed to delete employee: {e}")
    finally:
        db_connect.close()
#


def employee_login():
    username = employee_username_entry.get()
    password = employee_password_entry.get()
    if not username or not password:
        messagebox.showerror("ERROR", "Fill out all fields")
        return
    if authenticate_login(username,password,"employee"):
        employee_option()
    else:
        messagebox.showerror("Login Failed", "Invalid Information")


#--------------------------------------------------------------------------------------------------------------------

def add_product(name, price):
    if not name or not price:
        messagebox.showerror("Error", "Product name and price are required.")
        return

    try:
        price = float(price)
    except ValueError:
        messagebox.showerror("Error", "Price must be a valid number.")
        return

    db_connect = sqlite3.connect('database.db')
    cur_sor = db_connect.cursor()
    try:
        cur_sor.execute("INSERT INTO products (name, price) VALUES (?, ?)", (name, price))
        db_connect.commit()
        messagebox.showinfo("Success", f"Product '{name}' added successfully!")
    except sqlite3.IntegrityError:
        messagebox.showerror("Error", "Product already exists.")
    finally:
        db_connect.close()


def remove_product(name):
    if not name:
        messagebox.showerror("Error", "Please select a product to remove.")
        return

    db_connect = sqlite3.connect('database.db')
    cur_sor = db_connect.cursor()
    cur_sor.execute("DELETE FROM products WHERE name = ?", (name,))
    db_connect.commit()
    if cur_sor.rowcount > 0:
        messagebox.showinfo("Success", f"Product '{name}' removed successfully!")
    else:
        messagebox.showerror("Error", f"Product '{name}' not found.")
    db_connect.close()


def fetch_products():
    db_connect = sqlite3.connect('database.db')
    cur_sor = db_connect.cursor()
    cur_sor.execute("SELECT name, price FROM products")
    products = cur_sor.fetchall()
    db_connect.close()
    return products


def finalize_purchase(total_price):
    db_connect = sqlite3.connect('database.db')
    cur_sor = db_connect.cursor()
    cur_sor.execute("INSERT INTO sales (total_earning) VALUES (?)", (total_price,))
    db_connect.commit()
    db_connect.close()
    messagebox.showinfo("Success", "Purchase finalized! Earnings recorded.")



def manage_shop_function():
    def handle_add_product():
        name = product_name_entry.get()
        price = product_price_entry.get()
        add_product(name, price)
        update_product_listbox()

    def handle_remove_product():
        selected = products_listbox.get(tk.ACTIVE)
        if selected:
            name = selected.split(" - ")[0]
            remove_product(name)
            update_product_listbox()

    def update_product_listbox():
        products_listbox.delete(0, tk.END)
        for product in fetch_products():
            products_listbox.insert(tk.END, f"{product[0]} - PHP {product[1]:.2f}")

    global manage_shop_function_window
    manage_shop_function_window = tk.Toplevel(employee_option_viewboard)
    manage_shop_function_window.title("Manage Shop")
    manage_shop_function_window.geometry("800x600")
    manage_shop_function_window.configure(bg="lightgreen")
    manage_shop_function_window.transient(app)
    manage_shop_function_window.grab_set()


    manage_shop_frame = tk.Frame(manage_shop_function_window, width=700, height=500, bd=1, relief="solid")
    manage_shop_frame.pack(pady=10, padx=10)
    manage_shop_frame.pack_propagate(False)


    # Add Product
    tk.Label(manage_shop_frame, text="Product Name:", font=("Arial",14)).pack(pady=5)
    product_name_entry = tk.Entry(manage_shop_frame)
    product_name_entry.pack(pady=5)

    tk.Label(manage_shop_frame, text="Product Price:",font=("Arial",14)).pack(pady=5)
    product_price_entry = tk.Entry(manage_shop_frame)
    product_price_entry.pack(pady=5)

    add_product_button = tk.Button(manage_shop_frame, text="Add Product", font=("Arial",14), command=handle_add_product)
    add_product_button.pack(pady=10)

    # Remove Product
    remove_product_button = tk.Button(manage_shop_frame, text="Remove Selected Product", font=("Arial",14), command=handle_remove_product)
    remove_product_button.pack(pady=10)

    # Products Listbox
    products_listbox = tk.Listbox(manage_shop_frame, width=40)
    products_listbox.pack(pady=10)
    update_product_listbox()
    scrollbar3 = tk.Scrollbar(manage_shop_frame, orient=tk.VERTICAL, command=products_listbox.yview)
    scrollbar3.pack(side="right", fill=tk.Y)
    products_listbox.config(yscrollcommand=scrollbar3.set)


# Updated employee_viewboard
def employee_viewboard():
    global employee_overview, products_listbox, cart_listbox, total_label, payment_entry
    global cart

    cart = []

    def update_products_listbox():
        products_listbox.delete(0, tk.END)
        for product in fetch_products():
            products_listbox.insert(tk.END, f"{product[0]} - PHP {product[1]:.2f}")

    def add_to_cart():
        selected = products_listbox.get(tk.ACTIVE)
        if selected:
            name, price = selected.rsplit(" - PHP ", 1)
            cart.append((name, float(price)))
            cart_listbox.insert(tk.END, selected)
            update_total()

    def update_total():
        total_price = sum(item[1] for item in cart)
        total_label.config(text=f"Total Price: PHP {total_price:.2f}")

    def calculate_exchange():
        try:
            payment = float(payment_entry.get())
            total_price = sum(item[1] for item in cart)
            if payment < total_price:
                messagebox.showerror("Error", "Insufficient payment.")
            else:
                change = payment - total_price
                messagebox.showinfo("Change", f"Change: PHP {change:.2f}")
        except ValueError:
            messagebox.showerror("Error", "Please enter a valid payment amount.")

    def finalize():
        total_price = sum(item[1] for item in cart)
        if total_price > 0:
            finalize_purchase(total_price)
            cart.clear()
            cart_listbox.delete(0, tk.END)
            update_total()
        else:
            messagebox.showerror("Error", "Cart is empty.")



    employee_overview = tk.Toplevel(app)
    employee_overview.title("Employee Overview")
    employee_overview.geometry("1000x600")
    employee_overview.minsize(1000,600)
    employee_overview.configure(bg="lightgreen")
    employee_overview.transient(app)
    employee_overview.grab_set()

    
    #employee viewboard main frame
    employee_overview_frame = tk.Frame(employee_overview, width=1000, height=700, bd=1, relief="solid")
    employee_overview_frame.pack(pady=10, padx=10, expand=True, fill="both")
    employee_overview_frame.pack_propagate(False) 


    shop_main_label = tk.Label(employee_overview_frame, text="Shop", font=("Arial",18))
    shop_main_label.pack(pady=10,padx=10)

    employee_overview_frame_left_frame = tk.Frame(employee_overview_frame, width=200, height=600, bd=1, relief="solid")
    employee_overview_frame_left_frame.pack(pady=10, padx=10, side="left", expand=True, fill="both")
    tk.Label(employee_overview_frame_left_frame, text="Products: ", font=("Arial",14)).pack(pady=10,padx=10)


    employee_overview_frame_center_frame = tk.Frame(employee_overview_frame, width=200, height=600, bd=1, relief="solid")
    employee_overview_frame_center_frame.pack(pady=10, padx=10, side="left", expand=True, fill="both")


    employee_overview_frame_right_frame = tk.Frame(employee_overview_frame, width=200, height=600, bd=1, relief="solid")
    employee_overview_frame_right_frame.pack(pady=10, padx=10, side="left", expand=True, fill="both")
    tk.Label(employee_overview_frame_right_frame, text="Cart: ", font=("Arial",14)).pack(pady=10,padx=10)

    
    # Product Listbox
    products_listbox = tk.Listbox(employee_overview_frame_left_frame, width=50, height=50)
    products_listbox.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)
    update_products_listbox()
    scrollbar1 = tk.Scrollbar(employee_overview_frame_left_frame, orient=tk.VERTICAL, command=products_listbox.yview)
    scrollbar1.pack(side="right", fill=tk.Y)
    products_listbox.config(yscrollcommand=scrollbar1.set)
    

    # Add to Cart Button
    tk.Button(employee_overview_frame_center_frame, text="Add to Cart", command=add_to_cart).pack(pady=5)

    # Cart Listbox
    cart_listbox = tk.Listbox(employee_overview_frame_right_frame, width=50, height=50)
    cart_listbox.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)
    scrollbar2 = tk.Scrollbar(employee_overview_frame_right_frame, orient=tk.VERTICAL, command=cart_listbox.yview)
    scrollbar2.pack(side="right", fill=tk.Y)
    cart_listbox.config(yscrollcommand=scrollbar2.set)


    # Total and Payment
    total_label = tk.Label(employee_overview_frame_center_frame, text="Total Price: PHP 0", font=("Arial", 12))
    total_label.pack(pady=5)

    payment_label = tk.Label(employee_overview_frame_center_frame, text="Payment", font=("Arial", 12))
    payment_label.pack()
    payment_entry = tk.Entry(employee_overview_frame_center_frame)
    payment_entry.pack(pady=5)

    # Buttons
    tk.Button(employee_overview_frame_center_frame, text="Calculate Exchange", command=calculate_exchange).pack(pady=5)

    tk.Button(employee_overview_frame_center_frame, text="Finalize Purchase", command=finalize).pack(pady=5)

    #tk.Button(employee_overview_frame_center_frame, text="Manage Shop", command=manage_shop_function).pack(pady=10)

    
#-------------------------------------------------------------------------------------------------------------------------

def admin_login():
    username = admin_username_entry.get()
    password = admin_password_entry.get()

    if not username or not password:
        messagebox.showerror("Error", "Please fill out all fields")
        return

    if authenticate_login(username, password, "admin"):
        admin_viewboard()
    else:
        messagebox.showerror("Login Failed", "Invalid Information")


def admin_viewboard():
    admin_overview = tk.Toplevel(app)
    admin_overview.title("Administrator Overview")
    admin_overview.geometry("1000x600")
    admin_overview.minsize(1000,600)
    admin_overview.configure(bg="lightgreen")
    admin_overview.transient(app)
    admin_overview.grab_set()
    admin_overview.state('zoomed')

    admin_overview_main_label = tk.Label(admin_overview, text="Administrator Overview", font=("Arial",20))
    admin_overview_main_label.pack(pady="20")
    admin_overview_main_frame = tk.Frame(admin_overview, width="600", height="500", bd="1", relief="solid")
    admin_overview_main_frame.pack(pady="10")
    #admin_overview_main_frame.pack_propagate(False)

    create_employee_account_label = tk.Label(admin_overview_main_frame, text="Create employee account", font=("Arial",14))
    create_employee_account_label.pack(pady=5)
    create_employee_account = tk.Button(admin_overview_main_frame, text="Create account", font=("Arial", 12), command=create_account)
    create_employee_account.pack(pady=5)

    read_label = tk.Label(admin_overview_main_frame, text="View All Accounts", font=("Arial",14))
    read_label.pack(pady=5)

#-------------------------------------------------------------------------------------------------------------------------

    def display_employees():
            employees = read_employees()
            if employees:
                employee_list = "\n".join([f"ID: {emp[0]}, Username: {emp[1]}, Role: {emp[2]}" for emp in employees])
                messagebox.showinfo("Accounts List", employee_list)
            else:
                messagebox.showinfo("Accounts List", "No Account is found.")


    view_employees_button = tk.Button(admin_overview_main_frame, text="View All Accounts", font=("Arial", 12), command=display_employees)
    view_employees_button.pack(pady=10)

        # Update Employee Section
    update_employee_label = tk.Label(admin_overview_main_frame, text="Update Account", font=("Arial", 14))
    update_employee_label.pack(pady=10)

    update_username_label = tk.Label(admin_overview_main_frame, text="Username", font=("Arial", 12))
    update_username_label.pack(pady=5)
    update_username_entry = tk.Entry(admin_overview_main_frame)
    update_username_entry.pack(pady=5)

    update_password_label = tk.Label(admin_overview_main_frame, text="New Password", font=("Arial", 12))
    update_password_label.pack(pady=5)
    update_password_entry = tk.Entry(admin_overview_main_frame)
    update_password_entry.pack(pady=5)

    update_role_label = tk.Label(admin_overview_main_frame, text="New Role (""admin"" or ""employee"") ", font=("Arial", 12))
    update_role_label.pack(pady=5)
    update_role_entry = tk.Entry(admin_overview_main_frame)
    update_role_entry.pack(pady=5)

    update_employee_button = tk.Button(admin_overview_main_frame, text="Update Employee", font=("Arial", 12), 
                                            command=lambda: update_employee(update_username_entry.get(),
                                                                            update_password_entry.get(),
                                                                            update_role_entry.get()))
    update_employee_button.pack(pady=10)

    #Delete Employee Section
    delete_employee_label = tk.Label(admin_overview_main_frame, text="Delete Employee Account", font=("Arial", 14))
    delete_employee_label.pack(pady=10)

    delete_username_label = tk.Label(admin_overview_main_frame, text="Username: ", font=("Arial", 12))
    delete_username_label.pack(pady=5)
    delete_username_entry = tk.Entry(admin_overview_main_frame)
    delete_username_entry.pack(pady=5)

    delete_employee_button = tk.Button(admin_overview_main_frame, text="Delete Employee", font=("Arial", 12), 
                                            command=lambda: delete_employee(delete_username_entry.get()))
    delete_employee_button.pack(pady=10)




#-------------------------------------------------------------------------------------------------------------------------

def create_account():
    global create_employee_account_username_entry
    global create_employee_account_password_entry
    create_account_window = tk.Toplevel(app)
    create_account_window.title("Administrator Overview")
    create_account_window.geometry("1000x600")
    create_account_window.minsize(1000,600)
    create_account_window.configure(bg="lightgreen")
    create_account_window.transient(app)
    create_account_window.grab_set()

    create_account_main_label = tk.Label(create_account_window, text="Administrator Overview", font=("Arial",20))
    create_account_main_label.pack(pady="20")
    create_account_main_frame = tk.Frame(create_account_window, width="600", height="400", bd="1", relief="solid")
    create_account_main_frame.pack(pady="10")

    create_employee_account_username_label = tk.Label(create_account_main_frame, text="Register Username: ", font=("Arial",12))
    create_employee_account_username_label.pack(pady=10)
    create_employee_account_username_entry = tk.Entry(create_account_main_frame)
    create_employee_account_username_entry.pack(pady=10)

    create_employee_account_password_label = tk.Label(create_account_main_frame, text="Register Password: ", font=("Arial",12))
    create_employee_account_password_label.pack(pady=10)
    create_employee_account_password_entry = tk.Entry(create_account_main_frame)
    create_employee_account_password_entry.pack(pady=10)

    register_employee_account = tk.Button(create_account_main_frame, text="Register Account", font=("Arial", 12), command=register_account)
    register_employee_account.pack(pady=10)

def register_account():
    username = create_employee_account_username_entry.get()
    password = create_employee_account_password_entry.get()
    
    if not username or not password:
        messagebox.showerror("Error", "Both fields are required to register an account.")
        return

    # Database connection
    db_connect = sqlite3.connect('database.db')
    cur_sor = db_connect.cursor()

    # Check if the username already exists
    cur_sor.execute("SELECT * FROM employees WHERE username = ?", (username,))
    if cur_sor.fetchone():
        messagebox.showerror("Error", "Username already exists. Please choose a different username.")
        db_connect.close()
        return

    # Insert the new employee into the database
    cur_sor.execute("INSERT INTO employees (username, password, role) VALUES (?, ?, 'employee')", (username, password))
    db_connect.commit()
    db_connect.close()

    messagebox.showinfo("Success", f"Employee account '{username}' has been successfully registered.")
    create_employee_account_username_entry.delete(0, tk.END)
    create_employee_account_password_entry.delete(0, tk.END)

#-------------------------------------------------------------------------------------------------------------------------

def employee_option():
    global employee_option_viewboard
    employee_option_viewboard= tk.Toplevel(app)
    employee_option_viewboard.title("Option")
    employee_option_viewboard.geometry("400x300")
    #employee_option_viewboard.minsize(1000,600)
    employee_option_viewboard.configure(bg="lightgreen")
    employee_option_viewboard.transient(app)
    employee_option_viewboard.grab_set()


    employee_option_viewboard_frame = tk.Frame(employee_option_viewboard, width=200, height=150, bd=1, relief="solid")
    employee_option_viewboard_frame.pack(pady=10)
    employee_option_viewboard_frame.pack_propagate(False)

    to_shop_button = tk.Button(employee_option_viewboard_frame, text="Shop Viewboard", font=("Arial", 14),command=employee_viewboard)
    to_shop_button.pack(pady=10, side="top")

    to_manage_product_button = tk.Button(employee_option_viewboard_frame, text="Manage Product", font=("Arial", 14), command=manage_shop_function)
    to_manage_product_button.pack(pady=10, side="top")


#-------------------------------------------------------------------------------------------------------------------------

def Main():
    global employee_username_entry, employee_password_entry
    global admin_username_entry, admin_password_entry
    global app
    app = tk.Tk()
    app.title("POS System")
    app.geometry("1000x600")
    app.minsize(1000,600)
    app.configure(bg="lightgreen")
    app.resizable(False,False)

    main_label = tk.Label(app, text="Point of Sale System", font=("Arial",20))
    main_label.pack(pady=20)
    main_container = tk.Frame(app, width=600, height=400, bd=1, relief="solid")
    main_container.pack()
    #main_container.pack_propagate(False)
    
    login_label = tk.Label(main_container, text="Log in", font=("Arial",14))
    login_label.pack(pady=10)

    employee_username_label = tk.Label(main_container, text="Username:", font=("Arial",12))
    employee_username_label.pack()
    employee_username_entry = tk.Entry(main_container)
    employee_username_entry.pack()

    employee_password_label = tk.Label(main_container, text="Password:", font=("Arial",12))
    employee_password_label.pack()
    employee_password_entry = tk.Entry(main_container, show="*")
    employee_password_entry.pack(pady=10)

   # test_button  =tk.Button(main_container, text="click me", command=employee_option) #--------------------------------------------
  # test_button.pack(pady=10)

    login_submit_button = tk.Button(main_container, text="Sign in", font=("Arial", 12), command=employee_login)
    login_submit_button.pack(pady=10)

    line1 = tk.Label(main_container, text="--------------------------------------------------------------------",font=("Arial",12))
    line1.pack(pady=10)

    admin_login_label = tk.Label(main_container, text="Admin/Owner Log in", font=("Arial",14))
    admin_login_label.pack(pady=10)

    admin_username_label = tk.Label(main_container, text="Username:", font=("Arial",12))
    admin_username_label.pack()
    admin_username_entry = tk.Entry(main_container)
    admin_username_entry.pack(pady=10)

    admin_password_label = tk.Label(main_container, text="Password:", font=("Arial",12))
    admin_password_label.pack()
    admin_password_entry = tk.Entry(main_container, show="*")
    admin_password_entry.pack(pady=10)

    admin_submit_button = tk.Button(main_container, text="Sign in", font=("Arial", 12), command=admin_login)
    admin_submit_button.pack(pady=10)

    app.mainloop()

#-------------------------------------------------------------------------------------------------------------------------
if __name__=="__main__":
    Main()

    